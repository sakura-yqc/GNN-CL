import os
import re
import numpy as np
import pandas as pd
from tqdm import tqdm
import networkx as nx
from karateclub import DeepWalk
import argparse

# ===== 工具函数 =====

def collect_dataset_paths(node_dir, adj_dir):
    """
    Collect (node csv, 5 adjacency csvs) pairs for all valid frames in highD dataset.

    Returns:
        List of (node_csv_path, [adj_csv_paths])
    """
    dataset_pairs = []
    # Pattern: nodes_win{win}_frame{frame}.csv
    pattern = re.compile(r"nodes_win([0-9]+)_frame([0-9]+)\.csv")
    node_files = [f for f in os.listdir(node_dir) if f.startswith('nodes_win') and f.endswith('.csv')]
    for fname in node_files:
        match = pattern.match(fname)
        if not match:
            continue
        win, frame_id = match.groups()
        node_csv_path = os.path.join(node_dir, fname)
        adj_layers = ["angle", "latv", "lond", "latd", "lonv"]
        adj_csv_paths = []
        valid = True
        for layer in adj_layers:
            # adj_{layer}_win{win}_frame{frame}.csv
            adj_fname = f"adj_{layer}_win{win}_frame{frame_id}.csv"
            adj_path = os.path.join(adj_dir, adj_fname)
            if not os.path.exists(adj_path):
                valid = False
                break
            adj_csv_paths.append(adj_path)
        if valid:
            dataset_pairs.append((node_csv_path, adj_csv_paths))
    return dataset_pairs




def deepwalk_layer_embedding(adj_matrix, embedding_dim=32):
    G = nx.from_numpy_matrix(adj_matrix, create_using=nx.DiGraph)
    model = DeepWalk(dimensions=embedding_dim, walk_length=40, workers=1)
    model.fit(G)
    emb = model.get_embedding()  # shape: [N, embedding_dim]
    return emb, G

def get_five_deepwalk_emb_and_graphs(adj_csv_paths, embedding_dim=32):
    embeddings = []
    graphs = []
    for p in adj_csv_paths:
        adj = pd.read_csv(p, index_col=0).values  # N x N
        emb, G = deepwalk_layer_embedding(adj, embedding_dim)
        embeddings.append(emb)
        graphs.append(G)
    return embeddings, graphs

def calc_sparsity(delta_dict, sparsity_ratio=0.95, N=None):
    delta_vals = np.array(list(delta_dict.values()))
    if len(delta_vals) == 0:
        return 0.
    total = delta_vals.sum()
    if total == 0:
        return 0.
    delta_sorted = np.sort(delta_vals)[::-1]
    cumsum = np.cumsum(delta_sorted)
    num_sparse = np.searchsorted(cumsum, sparsity_ratio * total) + 1
    N_total = N if N is not None else len(delta_dict) + 1
    sparsity = num_sparse / (N_total - 1)
    return sparsity

def compute_pseudodist_topk(node_df, target_idx, top_k):
    xs = node_df['x'].values
    ys = node_df['y'].values
    vxs = node_df['vx'].values
    vys = node_df['vy'].values
    headings_deg = node_df['heading_angle'].values
    vs = np.sqrt(vxs ** 2 + vys ** 2)
    headings = np.deg2rad(headings_deg)
    x_ego, y_ego, v_ego, phi_ego = xs[target_idx], ys[target_idx], vs[target_idx], headings[target_idx]
    dx_global = xs - x_ego
    dy_global = ys - y_ego
    dx_rot = dx_global * np.cos(-phi_ego) - dy_global * np.sin(-phi_ego)
    dy_rot = dx_global * np.sin(-phi_ego) + dy_global * np.cos(-phi_ego)
    l, w, alpha = 4.5, 1.8, 0.056
    pseudo_distance = np.sqrt((dx_rot / (l * np.exp(alpha * v_ego))) ** 2 + (dy_rot / w) ** 2)
    pseudo_distance[target_idx] = np.inf
    pseudo_scores = {i: 1 / (pseudo_distance[i] + 1e-6) for i in range(len(xs)) if i != target_idx}
    pseudo_topk_nodes = [n for n, _ in sorted(pseudo_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]]
    return pseudo_topk_nodes

def neighbor_importance_by_delta(target_idx, five_adj_csvs, five_graphs, five_embs):
    deltas = dict()  # {(layer, neighbor): Δ值}
    N = five_embs[0].shape[0]
    embedding_dim = five_embs[0].shape[1]
    for layer, (G, adj_path) in enumerate(zip(five_graphs, five_adj_csvs)):
        adj = pd.read_csv(adj_path, index_col=0).values
        neighbors = list(G.successors(target_idx))
        for neighbor in neighbors:
            adj_mod = adj.copy()
            adj_mod[target_idx, neighbor] = 0
            emb_mod, _ = deepwalk_layer_embedding(adj_mod, embedding_dim)
            emb_stack = []
            for l in range(5):
                if l == layer:
                    emb_stack.append(emb_mod)
                else:
                    emb_stack.append(five_embs[l])
            emb_mean = np.mean(emb_stack, axis=0)
            emb_mean_orig = np.mean(five_embs, axis=0)
            delta = np.linalg.norm(emb_mean[target_idx] - emb_mean_orig[target_idx])
            deltas[(layer, neighbor)] = delta
    neighbor_delta = {}
    for lnb, delta in deltas.items():
        _, nb = lnb
        neighbor_delta[nb] = max(neighbor_delta.get(nb, 0), delta)
    return neighbor_delta



def main_deepwalk_delta_eval(node_dir, adj_dir, embedding_dim=32, threshold=0.0001):
    dataset_pairs = collect_dataset_paths(node_dir, adj_dir)
    print(f"Total matched frames: {len(dataset_pairs)}")
    all_frame_precision, all_frame_ndcg, all_frame_sparsity = [], [], []
    valid_frames = 0

    for node_csv_path, adj_csv_paths in tqdm(dataset_pairs, desc="DeepWalk Edge-Removal Sensitivity Evaluation"):
        node_df = pd.read_csv(node_csv_path)
        N = len(node_df)
        five_embs, five_graphs = get_five_deepwalk_emb_and_graphs(adj_csv_paths, embedding_dim)
        frame_precisions, frame_ndcgs, frame_sparsities = [], [], []

        for ego_idx in range(N):
            neighbor_delta = neighbor_importance_by_delta(ego_idx, adj_csv_paths, five_graphs, five_embs)
            sparsity = calc_sparsity(neighbor_delta, sparsity_ratio=0.95, N=N)

            num_others = N - 1
            real_k = min(5, num_others)
            if real_k < 1:
                continue

            filtered = sorted(neighbor_delta.items(), key=lambda x: x[1], reverse=True)[:real_k]
            if len(filtered) < 1:
                continue
            model_topk_nodes = [n for n, _ in filtered]
            pseudo_topk_nodes = compute_pseudodist_topk(node_df, ego_idx, real_k)

            # Compute Precision@K and NDCG@K
            common = len(set(model_topk_nodes) & set(pseudo_topk_nodes))
            precision_k = common / real_k
            dcg = 0
            for i, node in enumerate(model_topk_nodes):
                if node in pseudo_topk_nodes:
                    dcg += 1 / np.log2(i + 2)
            idcg = sum(1 / np.log2(i + 2) for i in range(real_k))
            ndcg_k = dcg / (idcg + 1e-8)

            frame_precisions.append(precision_k)
            frame_ndcgs.append(ndcg_k)
            frame_sparsities.append(sparsity)

        if frame_precisions:
            all_frame_precision.append(np.mean(frame_precisions))
            all_frame_ndcg.append(np.mean(frame_ndcgs))
            all_frame_sparsity.append(np.mean(frame_sparsities))
            valid_frames += 1

    mean_prec = np.mean(all_frame_precision) if all_frame_precision else 0
    mean_ndcg = np.mean(all_frame_ndcg) if all_frame_ndcg else 0
    mean_sparsity = np.mean(all_frame_sparsity) if all_frame_sparsity else 0

    print("\n========== DeepWalk Delta Baseline ==========")
    print(f"Overall mean Precision@K: {mean_prec:.4f}")
    print(f"Overall mean NDCG@K: {mean_ndcg:.4f}")
    print(f"Overall mean Sparsity: {mean_sparsity:.4f}")
    print(f"Valid frames: {valid_frames}")
    print("=============================================")

    # === Save results to results directory ===
    results_dir = "../../results"
    os.makedirs(results_dir, exist_ok=True)
    result_path = os.path.join(results_dir, "deepwalk_eval_summary.txt")
    with open(result_path, "w", encoding="utf-8") as f:
        f.write("========== DeepWalk Delta Baseline ==========\n")
        f.write(f"Overall mean Precision@K: {mean_prec:.4f}\n")
        f.write(f"Overall mean NDCG@K: {mean_ndcg:.4f}\n")
        f.write(f"Overall mean Sparsity: {mean_sparsity:.4f}\n")
        f.write(f"Valid frames: {valid_frames}\n")
        f.write("=============================================\n")
    print(f"\nResults have been saved to: {result_path}")

    return mean_prec, mean_ndcg, mean_sparsity, all_frame_precision, all_frame_ndcg, all_frame_sparsity

# ====== CLI Entrypoint ======
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DeepWalk Delta Baseline neighbor importance evaluation")
    parser.add_argument("--node_dir", type=str, required=False,
                        default="../../data/processed/highD/nodes/test",
                        help="Node feature CSV directory")
    parser.add_argument("--adj_dir", type=str, required=False,
                        default="../../data/processed/highD/adj/test",
                        help="Adjacency matrix CSV directory")
    parser.add_argument("--embedding_dim", type=int, default=32, help="DeepWalk embedding dimension")
    parser.add_argument("--threshold", type=float, default=0.0001, help="Threshold for sparsity and filtering")
    args = parser.parse_args()

    main_deepwalk_delta_eval(args.node_dir, args.adj_dir, args.embedding_dim, args.threshold)



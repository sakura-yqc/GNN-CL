import os
import re
import random
import numpy as np
import torch
import torch.nn as nn
import pandas as pd
from tqdm import tqdm
import argparse

# ======= GCN, Readout, Discriminator, and DGI Model Definition =======

class GCN(nn.Module):
    """
    Simple Graph Convolutional Network (GCN) layer for dense or sparse adjacency.
    """
    def __init__(self, in_ft, out_ft, act, bias=True):
        super(GCN, self).__init__()
        self.fc = nn.Linear(in_ft, out_ft, bias=False)
        self.act = nn.PReLU() if act == 'prelu' else act
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_ft))
            self.bias.data.fill_(0.0)
        else:
            self.register_parameter('bias', None)
        for m in self.modules():
            self.weights_init(m)
    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)
    def forward(self, seq, adj, sparse=False):
        # seq: (batch, N, F), adj: (batch, N, N)
        seq_fts = self.fc(seq)
        if sparse:
            out = torch.unsqueeze(torch.spmm(adj, torch.squeeze(seq_fts, 0)), 0)
        else:
            out = torch.bmm(adj, seq_fts)
        if self.bias is not None:
            out += self.bias
        return self.act(out)

class AvgReadout(nn.Module):
    """
    Compute (masked) mean of node embeddings as global summary vector.
    """
    def __init__(self):
        super(AvgReadout, self).__init__()
    def forward(self, seq, msk):
        if msk is None:
            return torch.mean(seq, 1)
        else:
            msk = torch.unsqueeze(msk, -1)
            return torch.sum(seq * msk, 1) / torch.sum(msk)

class Discriminator(nn.Module):
    """
    Bilinear discriminator for global-local DGI contrastive objective.
    """
    def __init__(self, n_h):
        super(Discriminator, self).__init__()
        self.f_k = nn.Bilinear(n_h, n_h, 1)
        for m in self.modules():
            self.weights_init(m)
    def weights_init(self, m):
        if isinstance(m, nn.Bilinear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)
    def forward(self, c, h_pl, h_mi, s_bias1=None, s_bias2=None):
        # c: (batch, h), h_pl/h_mi: (batch, N, h)
        c_x = torch.unsqueeze(c, 1)
        c_x = c_x.expand_as(h_pl)
        sc_1 = torch.squeeze(self.f_k(h_pl, c_x), 2)
        sc_2 = torch.squeeze(self.f_k(h_mi, c_x), 2)
        if s_bias1 is not None: sc_1 += s_bias1
        if s_bias2 is not None: sc_2 += s_bias2
        logits = torch.cat((sc_1, sc_2), 1)
        return logits

class DGI(nn.Module):
    """
    Deep Graph Infomax model: GCN encoder, global readout, and discriminator.
    """
    def __init__(self, n_in, n_h, activation):
        super(DGI, self).__init__()
        self.gcn = GCN(n_in, n_h, activation)
        self.read = AvgReadout()
        self.sigm = nn.Sigmoid()
        self.disc = Discriminator(n_h)
    def forward(self, seq1, seq2, adj, sparse, msk, samp_bias1, samp_bias2):
        h_1 = self.gcn(seq1, adj, sparse)
        c = self.read(h_1, msk)
        c = self.sigm(c)
        h_2 = self.gcn(seq2, adj, sparse)
        ret = self.disc(c, h_1, h_2, samp_bias1, samp_bias2)
        return ret
    def embed(self, seq, adj, sparse, msk):
        """
        Return (node embeddings, global graph summary) for evaluation or attribution.
        """
        h_1 = self.gcn(seq, adj, sparse)
        c = self.read(h_1, msk)
        return h_1.detach(), c.detach()

# ======= Data Handling and Loading =======

def row_normalize(A):
    """
    Row-normalize adjacency matrix (for GCN input).
    """
    A = A.copy()
    s = A.sum(axis=1, keepdims=True)
    s[s == 0] = 1
    return A / s

def collect_dataset_paths(node_dir, adj_dir):
    """
    Collect (node csv, 5 adjacency csvs) pairs for all valid frames in highD dataset.

    Returns:
        List of (node_csv_path, [adj_csv_paths])
    """
    dataset_pairs = []
    # Pattern: nodes_win{win}_frame{frame}.csv
    pattern = re.compile(r"nodes_win([0-9]+)_frame([0-9]+)\.csv")
    node_files = [f for f in os.listdir(node_dir) if f.startswith('nodes_win') and f.endswith('.csv')]
    for fname in node_files:
        match = pattern.match(fname)
        if not match:
            continue
        win, frame_id = match.groups()
        node_csv_path = os.path.join(node_dir, fname)
        adj_layers = ["angle", "latv", "lond", "latd", "lonv"]
        adj_csv_paths = []
        valid = True
        for layer in adj_layers:
            # adj_{layer}_win{win}_frame{frame}.csv
            adj_fname = f"adj_{layer}_win{win}_frame{frame_id}.csv"
            adj_path = os.path.join(adj_dir, adj_fname)
            if not os.path.exists(adj_path):
                valid = False
                break
            adj_csv_paths.append(adj_path)
        if valid:
            dataset_pairs.append((node_csv_path, adj_csv_paths))
    return dataset_pairs


def prepare_dgi_batch(dataset_pairs, layer_idx, feature_columns, device):
    """
    Prepare all node features and single-view adjacency matrices for a DGI layer.

    Returns:
        List of feature tensors, list of adjacency tensors.
    """
    feats_list, adj_list = [], []
    for node_csv_path, adj_csv_paths in dataset_pairs:
        node_df = pd.read_csv(node_csv_path, index_col=0)
        feats = torch.FloatTensor(node_df[feature_columns].values)
        adj = pd.read_csv(adj_csv_paths[layer_idx], index_col=0).values
        adj = row_normalize(adj).T
        adj = torch.FloatTensor(adj)
        feats_list.append(feats.to(device))
        adj_list.append(adj.to(device))
    return feats_list, adj_list

# ======= Multi-layer DGI Training and Hyperparameter Search =======

def train_dgi_multilayer(
    train_pairs, val_pairs, feature_columns,
    lr_list, emb_dim_list,
    device, epochs, batch_size):
    """
    Train a separate DGI model on each view (layer), perform grid search,
    and select best models according to validation Precision@10.

    Returns:
        List of best DGI models, dict of best params, and best validation score.
    """
    best_val_prec = -float('inf')
    best_models, best_params = None, None

    for lr in lr_list:
        for emb_dim in emb_dim_list:
            models = []
            for l in range(5):
                model = DGI(n_in=len(feature_columns), n_h=emb_dim, activation='prelu').to(device)
                optimizer = torch.optim.Adam(model.parameters(), lr=lr)
                b_xent = nn.BCEWithLogitsLoss()
                model.train()
                # Prepare all training data for this layer
                feats_list, adj_list = prepare_dgi_batch(train_pairs, l, feature_columns, device)
                num_samples = len(feats_list)
                num_batches = int(np.ceil(num_samples / batch_size))
                for epoch in range(epochs):
                    indices = np.arange(num_samples)
                    np.random.shuffle(indices)
                    for batch_idx in range(num_batches):
                        batch_ids = indices[batch_idx*batch_size : (batch_idx+1)*batch_size]
                        for i in batch_ids:
                            feats = feats_list[i].unsqueeze(0)
                            adj = adj_list[i].unsqueeze(0)
                            N = feats.shape[1]
                            idx = torch.randperm(N)
                            shuf_feats = feats[:, idx, :]
                            lbl_1 = torch.ones(1, N, device=device)
                            lbl_2 = torch.zeros(1, N, device=device)
                            lbl = torch.cat((lbl_1, lbl_2), 1)
                            logits = model(feats, shuf_feats, adj, False, None, None, None)
                            loss = b_xent(logits, lbl)
                            optimizer.zero_grad()
                            loss.backward()
                            optimizer.step()
                models.append(model)
            # Evaluate on validation set
            val_prec, _, _ = evaluate_all_frames_dgi(val_pairs, feature_columns, models, device, top_k=10)
            print(f"[GridSearch] lr={lr}, emb_dim={emb_dim} | Val Precision@10={val_prec:.4f}")
            if val_prec > best_val_prec:
                best_val_prec = val_prec
                best_models = [m for m in models]
                best_params = {"lr": lr, "emb_dim": emb_dim}
    print(f"Best hyperparams: {best_params}, Best val Precision@10: {best_val_prec:.4f}")
    return best_models, best_params, best_val_prec

# ======= Attribution and Evaluation =======

def load_feats_and_adjs(node_csv_path, adj_csv_paths, feature_columns, device):
    """
    Load feature and adjacency tensors for a single frame.
    """
    node_df = pd.read_csv(node_csv_path, index_col=0)
    feats_np = node_df[feature_columns].values.astype(np.float32)
    feats = torch.FloatTensor(feats_np).unsqueeze(0).to(device)
    adjs = []
    for p in adj_csv_paths:
        A = pd.read_csv(p, index_col=0).values
        A_norm = row_normalize(A)
        A_flip = A_norm.T
        adjs.append(torch.FloatTensor(A_flip).unsqueeze(0).to(device))
    return feats, adjs, node_df

@torch.no_grad()
def neighbor_importance_dgi(feats, adjs, models, target_idx, device="cuda"):
    """
    Quantify the importance of each neighbor for a target node by measuring
    embedding changes when removing each neighbor's edge.

    Returns:
        dict: neighbor index -> importance delta
    """
    N = feats.shape[1]
    h_layers = []
    for l in range(len(models)):
        h, _ = models[l].embed(feats, adjs[l], False, None)
        h_layers.append(h.squeeze(0))
    h_fused = torch.stack(h_layers, dim=0).mean(dim=0)
    orig_embed = h_fused[target_idx].detach().cpu()
    neighbors_set = set()
    for l in range(len(models)):
        adj = adjs[l].squeeze(0)
        nb_idxs = (adj[target_idx] > 0).nonzero(as_tuple=True)[0].tolist()
        neighbors_set.update(nb_idxs)
    if target_idx in neighbors_set:
        neighbors_set.remove(target_idx)
    delta_dict = {}
    for nb in neighbors_set:
        adjs_mod = []
        for l in range(len(models)):
            adj_mod = adjs[l].clone()
            adj_mod[0, target_idx, nb] = 0
            adjs_mod.append(adj_mod)
        h_mods = []
        for l in range(len(models)):
            h, _ = models[l].embed(feats, adjs_mod[l], False, None)
            h_mods.append(h.squeeze(0))
        h_mod_fused = torch.stack(h_mods, dim=0).mean(dim=0)
        delta = torch.norm(h_mod_fused[target_idx].cpu() - orig_embed).item()
        delta_dict[nb] = delta
    return delta_dict

def evaluate_neighbor_importance_with_pseudodist(delta_dict, node_df, target_idx, top_k=10):
    """
    Compare model neighbor ranking with pseudo-risk top-K and compute evaluation metrics.

    Returns:
        tuple: (precision_k, ndcg_k, sparsity, model_topk_nodes, pseudo_topk_nodes)
    """
    N = len(node_df)
    k = min(top_k, N-1)
    model_sorted = sorted(delta_dict.items(), key=lambda x: x[1], reverse=True)
    model_topk_nodes = [n for n, _ in model_sorted[:k]]
    xs = node_df['x'].values
    ys = node_df['y'].values
    vxs = node_df['vx'].values
    vys = node_df['vy'].values
    headings_deg = node_df['heading_angle'].values
    vs = np.sqrt(vxs**2 + vys**2)
    headings = np.deg2rad(headings_deg)
    x_ego, y_ego, v_ego, phi_ego = xs[target_idx], ys[target_idx], vs[target_idx], headings[target_idx]
    dx_global = xs - x_ego
    dy_global = ys - y_ego
    dx_rot = dx_global * np.cos(-phi_ego) - dy_global * np.sin(-phi_ego)
    dy_rot = dx_global * np.sin(-phi_ego) + dy_global * np.cos(-phi_ego)
    l, w, alpha = 4.5, 1.8, 0.056
    pseudo_distance = np.sqrt((dx_rot / (l * np.exp(alpha * v_ego)))**2 + (dy_rot / w)**2)
    pseudo_distance[target_idx] = np.inf
    pseudo_scores = {i: 1 / (pseudo_distance[i] + 1e-6) for i in range(N) if i != target_idx}
    pseudo_topk_nodes = [n for n, _ in sorted(pseudo_scores.items(), key=lambda x: x[1], reverse=True)[:k]]
    precision_k = len(set(model_topk_nodes) & set(pseudo_topk_nodes)) / k if k > 0 else 0
    dcg = 0
    for i, node in enumerate(model_topk_nodes):
        if node in pseudo_topk_nodes:
            dcg += 1 / np.log2(i + 2)
    idcg = sum(1 / np.log2(i + 2) for i in range(k))
    ndcg_k = dcg / (idcg + 1e-8) if idcg > 0 else 0
    delta_vals = np.array([v for _, v in model_sorted])
    total = delta_vals.sum()
    if total > 0:
        delta_sorted = np.sort(delta_vals)[::-1]
        cumsum = np.cumsum(delta_sorted)
        num = np.searchsorted(cumsum, 0.95 * total) + 1
        sparsity = num / (N - 1) if N > 1 else 0.
    else:
        sparsity = 0.
    return precision_k, ndcg_k, sparsity, model_topk_nodes, pseudo_topk_nodes

def evaluate_frame_metrics_dgi(feats, adjs, models, node_df, top_k=10, device="cuda"):
    """
    Evaluate all node attribution metrics for a frame using trained DGI models.

    Returns:
        mean_precision, mean_ndcg, mean_sparsity, [prec list], [ndcg list], [sparsity list]
    """
    N = feats.shape[1]
    all_precision, all_ndcg, all_sparsity = [], [], []
    for target_idx in range(N):
        delta_dict = neighbor_importance_dgi(feats, adjs, models, target_idx, device=device)
        prec_k, ndcg_k, sparsity, _, _ = evaluate_neighbor_importance_with_pseudodist(
            delta_dict, node_df, target_idx, top_k=top_k
        )
        all_precision.append(prec_k)
        all_ndcg.append(ndcg_k)
        all_sparsity.append(sparsity)
    mean_prec = np.mean(all_precision) if all_precision else 0
    mean_ndcg = np.mean(all_ndcg) if all_ndcg else 0
    mean_sparsity = np.mean(all_sparsity) if all_sparsity else 0
    return mean_prec, mean_ndcg, mean_sparsity, all_precision, all_ndcg, all_sparsity

def evaluate_all_frames_dgi(dataset_pairs, feature_columns, models, device, top_k=5):
    """
    Run attribution and evaluation metrics on all frames in a dataset split.

    Returns:
        overall_prec, overall_ndcg, overall_sparsity
    """
    all_prec, all_ndcg, all_sparsity = [], [], []
    valid_frames = 0
    for node_csv_path, adj_csv_paths in tqdm(dataset_pairs, desc="DGI frame evaluation"):
        feats, adjs, node_df = load_feats_and_adjs(node_csv_path, adj_csv_paths, feature_columns, device)
        mean_prec, mean_ndcg, mean_sparsity, frame_prec, frame_ndcg, frame_sparsity = evaluate_frame_metrics_dgi(
            feats, adjs, models, node_df, top_k=top_k, device=device
        )
        if frame_prec:
            valid_frames += 1
            all_prec.extend(frame_prec)
            all_ndcg.extend(frame_ndcg)
            all_sparsity.extend(frame_sparsity)
            print(f"Frame {os.path.basename(node_csv_path)}: Prec@{top_k}={mean_prec:.4f} NDCG@{top_k}={mean_ndcg:.4f} Sparsity={mean_sparsity:.4f}")
    overall_prec = np.mean(all_prec) if all_prec else 0
    overall_ndcg = np.mean(all_ndcg) if all_ndcg else 0
    overall_sparsity = np.mean(all_sparsity) if all_sparsity else 0
    print(f"\n==== TestSet metrics summary ====")
    print(f"Frames evaluated: {valid_frames}/{len(dataset_pairs)}")
    print(f"Overall Precision@{top_k}: {overall_prec:.4f}")
    print(f"Overall NDCG@{top_k}: {overall_ndcg:.4f}")
    print(f"Overall Sparsity: {overall_sparsity:.4f}")
    return overall_prec, overall_ndcg, overall_sparsity


# ======= Main Entrypoint =======
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DGI multi-view hyperparameter search and attribution evaluation")
    parser.add_argument('--train_nodes_dir', type=str, required=False,
                        default="../../data/processed/highD/nodes/train")
    parser.add_argument('--train_adj_dir', type=str, required=False,
                        default="../../data/processed/highD/adj/train")
    parser.add_argument('--val_nodes_dir', type=str, required=False,
                        default="../../data/processed/highD/nodes/val")
    parser.add_argument('--val_adj_dir', type=str, required=False,
                        default="../../data/processed/highD/adj/val")
    parser.add_argument('--test_nodes_dir', type=str, required=False,
                        default="../../data/processed/highD/nodes/test")
    parser.add_argument('--test_adj_dir', type=str, required=False,
                        default="../../data/processed/highD/adj/test")
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--feature_columns', nargs='+', default=["x", "y", "vx", "vy", "sie", "heading_angle"])
    parser.add_argument('--results_dir', type=str, default='../../results', help='Directory to save evaluation results')
    parser.add_argument('--results_filename', type=str, default='dgi_eval_summary.txt', help='Evaluation result filename')
    args = parser.parse_args()

    lr_list = [0.01, 0.001, 0.0001]
    emb_dim_list = [16, 32, 64, 128]


    print("[Loading train/val/test sets...]")
    train_pairs = collect_dataset_paths(args.train_nodes_dir, args.train_adj_dir)
    val_pairs = collect_dataset_paths(args.val_nodes_dir, args.val_adj_dir)
    test_pairs = collect_dataset_paths(args.test_nodes_dir, args.test_adj_dir)
    print(f"Train: {len(train_pairs)}, Val: {len(val_pairs)}, Test: {len(test_pairs)}")


    print("\n=== Hyperparameter search (validation set) ===")
    best_models, best_params, best_val_prec = train_dgi_multilayer(
        train_pairs, val_pairs, args.feature_columns,
        lr_list, emb_dim_list,
        device=args.device, epochs=args.epochs, batch_size=args.batch_size
    )


    print("\n=== Evaluate best model on test set ===")
    overall_prec, overall_ndcg, overall_sparsity = evaluate_all_frames_dgi(
        test_pairs, args.feature_columns, best_models, device=args.device, top_k=5
    )
    print(f"\nFinal TestSet Precision@5: {overall_prec:.4f}")
    print(f"Final TestSet NDCG5: {overall_ndcg:.4f}")
    print(f"Final TestSet Sparsity: {overall_sparsity:.4f}")


    os.makedirs(args.results_dir, exist_ok=True)
    results_path = os.path.join(args.results_dir, args.results_filename)
    with open(results_path, "w", encoding="utf-8") as f:
        f.write("========== DGI Multi-View Evaluation ==========\n")
        f.write(f"Final TestSet Precision@5: {overall_prec:.4f}\n")
        f.write(f"Final TestSet NDCG@5: {overall_ndcg:.4f}\n")
        f.write(f"Final TestSet Sparsity: {overall_sparsity:.4f}\n")
        f.write("===============================================\n")
    print(f"\nEvaluation results saved to: {results_path}")


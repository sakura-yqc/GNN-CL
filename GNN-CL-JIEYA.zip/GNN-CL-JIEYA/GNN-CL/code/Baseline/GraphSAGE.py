import os
import re
import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
import numpy as np
import random
from tqdm import tqdm
from torch_geometric.nn import SAGEConv
from torch_geometric.data import Data, Batch
import argparse

# ==== Utility functions ====

def adj_to_edge_index(adj: np.ndarray) -> torch.Tensor:
    """
    Convert an adjacency matrix to PyTorch edge_index format.
    Args:
        adj (np.ndarray): Adjacency matrix (N x N)
    Returns:
        edge_index (torch.Tensor): Edge index (2, num_edges)
    """
    src, tgt = np.nonzero(adj)
    arr = np.array([src, tgt])
    return torch.from_numpy(arr).long()

def row_normalize(matrix: np.ndarray) -> np.ndarray:
    """
    Row-normalize a matrix (row sums to 1).
    """
    row_sums = matrix.sum(axis=1, keepdims=True) + 1e-8
    return matrix / row_sums

def load_node_and_multi_adjs(node_csv_path: str, adj_csv_paths, feature_columns, eval_unsqueeze=False):
    """
    Load node features and multi-view adjacency matrices for a given frame.
    Args:
        node_csv_path (str): Path to node CSV file.
        adj_csv_paths (list): List of adjacency matrix CSV paths.
        feature_columns (list): Columns to use as node features.
        eval_unsqueeze (bool): Whether to unsqueeze for batch dimension.
    Returns:
        feats (torch.Tensor): Node feature matrix.
        adjs (list): List of adjacency matrices.
        node_df (pd.DataFrame): Raw node dataframe.
    """
    node_df = pd.read_csv(node_csv_path, index_col=0)
    feats_np = node_df[feature_columns].values.astype(np.float32)
    if eval_unsqueeze:
        feats = torch.FloatTensor(feats_np).unsqueeze(0)
    else:
        feats = torch.FloatTensor(feats_np)
    adjs = []
    for p in adj_csv_paths:
        A = pd.read_csv(p, index_col=0).values.astype(np.float32)
        A_norm = row_normalize(A)
        A_flip = A_norm.T
        if eval_unsqueeze:
            adjs.append(torch.FloatTensor(A_flip).unsqueeze(0))
        else:
            adjs.append(torch.FloatTensor(A_flip))
    return feats, adjs, node_df

def collect_dataset_paths(node_dir, adj_dir):
    """
    Collect (node csv, 5 adjacency csvs) pairs for all valid frames in highD dataset.

    Returns:
        List of (node_csv_path, [adj_csv_paths])
    """
    dataset_pairs = []
    # Pattern: nodes_win{win}_frame{frame}.csv
    pattern = re.compile(r"nodes_win([0-9]+)_frame([0-9]+)\.csv")
    node_files = [f for f in os.listdir(node_dir) if f.startswith('nodes_win') and f.endswith('.csv')]
    for fname in node_files:
        match = pattern.match(fname)
        if not match:
            continue
        win, frame_id = match.groups()
        node_csv_path = os.path.join(node_dir, fname)
        adj_layers = ["angle", "latv", "lond", "latd", "lonv"]
        adj_csv_paths = []
        valid = True
        for layer in adj_layers:
            # adj_{layer}_win{win}_frame{frame}.csv
            adj_fname = f"adj_{layer}_win{win}_frame{frame_id}.csv"
            adj_path = os.path.join(adj_dir, adj_fname)
            if not os.path.exists(adj_path):
                valid = False
                break
            adj_csv_paths.append(adj_path)
        if valid:
            dataset_pairs.append((node_csv_path, adj_csv_paths))
    return dataset_pairs

def prepare_data_list(dataset_pairs, layer_idx, feature_columns, device):
    """
    Prepare PyG Data objects for a given risk view.
    Args:
        dataset_pairs: List of (node_csv_path, [adj_csv_paths])
        layer_idx: Index for risk view (0-4)
        feature_columns: Feature column names
        device: Target device
    Returns:
        List of PyG Data objects for GraphSAGE training
    """
    data_list = []
    for node_csv_path, adj_csv_paths in dataset_pairs:
        feats, adjs, node_df = load_node_and_multi_adjs(node_csv_path, adj_csv_paths, feature_columns)
        x = feats.to(device)
        adj = adjs[layer_idx].cpu().numpy()
        edge_index = adj_to_edge_index(adj).to(device)
        data = Data(x=x, edge_index=edge_index)
        data_list.append(data)
    return data_list

# ==== GraphSAGE Model ====

class SAGEEncoder(nn.Module):
    """
    Multi-layer GraphSAGE encoder for node embeddings.
    """
    def __init__(self, in_dim: int, hid_dim: int, out_dim: int, num_layers: int = 2):
        super().__init__()
        self.convs = nn.ModuleList()
        self.convs.append(SAGEConv(in_dim, hid_dim))
        for _ in range(num_layers - 2):
            self.convs.append(SAGEConv(hid_dim, hid_dim))
        self.convs.append(SAGEConv(hid_dim, out_dim))
        self.prelu = nn.PReLU()
    def forward(self, x, edge_index, batch=None):
        for conv in self.convs[:-1]:
            x = self.prelu(conv(x, edge_index))
        x = self.convs[-1](x, edge_index)
        return x

def contrastive_loss_batch(node_emb, node_emb_shuf, batch, readout_func):
    """
    Batched contrastive loss for GraphSAGE, DGI-style (global summary vector).
    """
    device = node_emb.device
    losses = []
    batch = batch.cpu().numpy() if batch is not None else np.zeros(node_emb.size(0), dtype=int)
    graph_ids = np.unique(batch)
    for gid in graph_ids:
        idx = np.where(batch == gid)[0]
        h = node_emb[idx]
        h_shuf = node_emb_shuf[idx]
        summary = torch.sigmoid(readout_func(h))
        pos = torch.matmul(h, summary.t())
        neg = torch.matmul(h_shuf, summary.t())
        lbl = torch.cat([torch.ones_like(pos), torch.zeros_like(neg)], dim=0)
        logits = torch.cat([pos, neg], dim=0)
        losses.append(F.binary_cross_entropy_with_logits(logits, lbl))
    return torch.stack(losses).mean()

# ========== Attribution and Evaluation ==========

def calc_sparsity(delta_dict, sparsity_ratio=0.95, N=None):
    """
    Compute sparsity: minimal #neighbors covering most importance.
    """
    delta_vals = np.array(list(delta_dict.values()))
    if len(delta_vals) == 0:
        return 0.
    total = delta_vals.sum()
    if total == 0:
        return 0.
    delta_sorted = np.sort(delta_vals)[::-1]
    cumsum = np.cumsum(delta_sorted)
    num_sparse = np.searchsorted(cumsum, sparsity_ratio * total) + 1
    N_total = N if N is not None else len(delta_dict) + 1
    sparsity = num_sparse / (N_total - 1)
    return sparsity

def evaluate_neighbor_importance(delta_dict, node_df, target_idx, top_k=5):
    """
    Compare top-k important neighbors (model vs. pseudo-distance baseline).
    Returns:
        precision_k, ndcg_k, model_topk_nodes, pseudo_topk_nodes
    """
    N = len(node_df)
    real_k = min(top_k, N - 1)
    if real_k < 1:
        return None, None, [], []
    model_sorted = sorted(delta_dict.items(), key=lambda x: x[1], reverse=True)
    model_topk_nodes = [n for n, _ in model_sorted[:real_k]]
    xs = node_df['x'].values
    ys = node_df['y'].values
    vxs = node_df['vx'].values
    vys = node_df['vy'].values
    headings_deg = node_df['heading_angle'].values
    vs = np.sqrt(vxs ** 2 + vys ** 2)
    headings = np.deg2rad(headings_deg)
    x_ego, y_ego, v_ego, phi_ego = xs[target_idx], ys[target_idx], vs[target_idx], headings[target_idx]
    dx_global = xs - x_ego
    dy_global = ys - y_ego
    dx_rot = dx_global * np.cos(-phi_ego) - dy_global * np.sin(-phi_ego)
    dy_rot = dx_global * np.sin(-phi_ego) + dy_global * np.cos(-phi_ego)
    l, w, alpha = 4.5, 1.8, 0.056
    pseudo_distance = np.sqrt((dx_rot / (l * np.exp(alpha * v_ego))) ** 2 + (dy_rot / w) ** 2)
    pseudo_distance[target_idx] = np.inf
    pseudo_scores = {i: 1 / (pseudo_distance[i] + 1e-6) for i in range(N) if i != target_idx}
    pseudo_topk_nodes = [n for n, _ in sorted(pseudo_scores.items(), key=lambda x: x[1], reverse=True)[:real_k]]
    common = len(set(model_topk_nodes) & set(pseudo_topk_nodes))
    precision_k = common / real_k if real_k > 0 else 0
    dcg = 0
    for i, node in enumerate(model_topk_nodes):
        if node in pseudo_topk_nodes:
            dcg += 1 / np.log2(i + 2)
    idcg = sum(1 / np.log2(i + 2) for i in range(real_k))
    ndcg_k = dcg / (idcg + 1e-8) if idcg > 0 else 0
    return precision_k, ndcg_k, model_topk_nodes, pseudo_topk_nodes

@torch.no_grad()
def neighbor_importance_graphsage_mean(
    feats, adjs, models, target_idx, device="cuda"
):
    """
    For a given target node, compute neighbor importance (across all risk views)
    by measuring mean embedding change after neighbor removal.
    Returns:
        dict: neighbor index -> importance delta
    """
    x = feats.squeeze(0).to(device)
    N = x.shape[0]
    orig_embeds = []
    for l in range(5):
        adj = adjs[l].squeeze(0).cpu().numpy()
        edge_index = adj_to_edge_index(adj).to(device)
        h = models[l](x, edge_index)[target_idx].detach().cpu().numpy()
        orig_embeds.append(h)
    h_orig = np.mean(orig_embeds, axis=0)
    adj0 = adjs[0].squeeze(0).cpu().numpy()
    neighbors = np.where(adj0[:, target_idx] > 0)[0].tolist()
    delta_dict = {}
    for nb in neighbors:
        embeds_masked = []
        for l in range(5):
            adj = adjs[l].squeeze(0).cpu().numpy().copy()
            adj[nb, target_idx] = 0
            edge_index = adj_to_edge_index(adj).to(device)
            h = models[l](x, edge_index)[target_idx].detach().cpu().numpy()
            embeds_masked.append(h)
        h_masked = np.mean(embeds_masked, axis=0)
        delta = np.linalg.norm(h_orig - h_masked)
        delta_dict[nb] = delta
    return delta_dict

def evaluate_all_nodes_graphsage_mean(feats, adjs, models, node_df, top_k=5, device="cuda"):
    """
    Attribution and evaluation for all nodes in a frame.
    Returns:
        mean_precision, mean_ndcg, mean_sparsity, frame_precision_list, frame_ndcg_list, frame_sparsity_list
    """
    N = feats.shape[1]
    frame_prec, frame_ndcg, frame_sparsity = [], [], []
    for target_idx in range(N):
        delta_dict = neighbor_importance_graphsage_mean(
            feats=feats, adjs=adjs, models=models,
            target_idx=target_idx, device=device
        )
        precision_k, ndcg_k, _, _ = evaluate_neighbor_importance(delta_dict, node_df, target_idx, top_k=top_k)
        sparsity = calc_sparsity(delta_dict, sparsity_ratio=0.95, N=N)
        if precision_k is not None:
            frame_prec.append(precision_k)
            frame_ndcg.append(ndcg_k)
            frame_sparsity.append(sparsity)
    mean_prec = np.mean(frame_prec) if frame_prec else 0
    mean_ndcg = np.mean(frame_ndcg) if frame_ndcg else 0
    mean_sparsity = np.mean(frame_sparsity) if frame_sparsity else 0
    return mean_prec, mean_ndcg, mean_sparsity, frame_prec, frame_ndcg, frame_sparsity

def evaluate_all_frames_graphsage_mean(
    node_dir, adj_dir, feature_columns, models, top_k=5, device="cuda", sample_num=100, random_seed=42
):
    """
    Evaluate all frames and output overall metrics.
    Returns:
        overall_precision, overall_ndcg, overall_sparsity, all_prec, all_ndcg, all_sparsity
    """
    dataset_pairs = collect_dataset_paths(node_dir, adj_dir)
    all_prec, all_ndcg, all_sparsity = [], [], []
    valid_frame_count = 0

    for node_csv_path, adj_csv_paths in tqdm(dataset_pairs, desc="Evaluating all frames"):
        feats, adjs, node_df = load_node_and_multi_adjs(node_csv_path, adj_csv_paths, feature_columns, eval_unsqueeze=True)
        mean_prec, mean_ndcg, mean_sparsity, frame_prec, frame_ndcg, frame_sparsity = evaluate_all_nodes_graphsage_mean(
            feats=feats,
            adjs=adjs,
            models=models,
            node_df=node_df,
            top_k=top_k,
            device=device
        )
        if len(frame_prec) > 0:
            all_prec.extend(frame_prec)
            all_ndcg.extend(frame_ndcg)
            all_sparsity.extend(frame_sparsity)
            valid_frame_count += 1
            print(f"Frame {os.path.basename(node_csv_path)}: Precision={mean_prec:.4f}, NDCG={mean_ndcg:.4f}, Sparsity={mean_sparsity:.4f}")

    overall_prec = np.mean(all_prec) if all_prec else 0
    overall_ndcg = np.mean(all_ndcg) if all_ndcg else 0
    overall_sparsity = np.mean(all_sparsity) if all_sparsity else 0
    print(f"\n==== Global Precision@{top_k}: {overall_prec:.4f} ====")
    print(f"==== Global NDCG@{top_k}: {overall_ndcg:.4f} ====")
    print(f"==== Global Sparsity: {overall_sparsity:.4f} ====")
    print(f"Total evaluated frames: {valid_frame_count}, Total nodes: {len(all_prec)}")
    return overall_prec, overall_ndcg, overall_sparsity, all_prec, all_ndcg, all_sparsity

# ==== Training, validation, and test pipeline ====

def train_and_eval(
    train_pairs, val_pairs, feature_columns,
    lr_list, emb_dim_list,
    device, epochs, batch_size
):
    """
    Multi-layer GraphSAGE grid search training and validation.
    Returns:
        best_models, best_params, best_val_score
    """
    best_val_score = -float('inf')
    best_params = {}
    best_models = None

    for lr in lr_list:
        for emb_dim in emb_dim_list:
            models = []
            for l in range(5):
                model = SAGEEncoder(len(feature_columns), emb_dim, emb_dim, num_layers=2).to(device)
                optimizer = torch.optim.Adam(model.parameters(), lr=lr)
                model.train()
                train_data_list = prepare_data_list(train_pairs, l, feature_columns, device)
                num_batches = int(np.ceil(len(train_data_list) / batch_size))
                for epoch in range(epochs):
                    random.shuffle(train_data_list)
                    for batch_idx in range(num_batches):
                        batch_datas = train_data_list[batch_idx*batch_size : (batch_idx+1)*batch_size]
                        batch = Batch.from_data_list(batch_datas).to(device)
                        x = batch.x
                        edge_index = batch.edge_index
                        batch_id = batch.batch
                        # Shuffle node features within each graph
                        shuf_x = []
                        for gid in batch_id.unique():
                            idx = (batch_id == gid)
                            sub_x = x[idx]
                            shuf_sub_x = sub_x[torch.randperm(sub_x.size(0))]
                            shuf_x.append(shuf_sub_x)
                        x_shuf = torch.cat(shuf_x, dim=0)
                        emb = model(x, edge_index, batch_id)
                        emb_shuf = model(x_shuf, edge_index, batch_id)
                        loss = contrastive_loss_batch(emb, emb_shuf, batch_id, lambda h: h.mean(dim=0, keepdim=True))
                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()
                models.append(model)
            # --- Evaluate on validation set ---
            val_score, _, _, _, _, _ = evaluate_all_frames_graphsage_mean(
                val_nodes_dir, val_adj_dir, feature_columns, models, top_k=10, device=device)
            print(f"[GridSearch] lr={lr}, emb_dim={emb_dim} | Val Precision@10={val_score:.4f}")
            if val_score > best_val_score:
                best_val_score = val_score
                best_params = {"lr": lr, "emb_dim": emb_dim}
                best_models = [m for m in models]
    print(f"Best hyperparams: {best_params}, Best val Precision@10: {best_val_score:.4f}")
    return best_models, best_params, best_val_score

# ==== Main entrypoint ====
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Multi-layer GraphSAGE training/validation/attribution")
    parser.add_argument('--train_nodes_dir', type=str, required=False,
                        default='../../data/processed/highD/nodes/train')
    parser.add_argument('--train_adj_dir', type=str, required=False,
                        default='../../data/processed/highD/adj/train')
    parser.add_argument('--val_nodes_dir', type=str, required=False,
                        default='../../data/processed/highD/nodes/val')
    parser.add_argument('--val_adj_dir', type=str, required=False,
                        default='../../data/processed/highD/adj/val')
    parser.add_argument('--test_nodes_dir', type=str, required=False,
                        default='../../data/processed/highD/nodes/test')
    parser.add_argument('--test_adj_dir', type=str, required=False,
                        default='../../data/processed/highD/adj/test')
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--feature_columns', nargs='+', default=["x", "y", "vx", "vy", "sie", "heading_angle"])
    args = parser.parse_args()

    lr_list = [0.01, 0.001, 0.0001]
    emb_dim_list = [16, 32, 64, 128]

    train_nodes_dir, train_adj_dir = args.train_nodes_dir, args.train_adj_dir
    val_nodes_dir, val_adj_dir = args.val_nodes_dir, args.val_adj_dir
    test_nodes_dir, test_adj_dir = args.test_nodes_dir, args.test_adj_dir

    feature_columns = args.feature_columns
    device = args.device

    print("[Loading train/val/test sets...]")
    train_pairs = collect_dataset_paths(train_nodes_dir, train_adj_dir)
    val_pairs = collect_dataset_paths(val_nodes_dir, val_adj_dir)
    test_pairs = collect_dataset_paths(test_nodes_dir, test_adj_dir)
    print(f"Train: {len(train_pairs)}, Val: {len(val_pairs)}, Test: {len(test_pairs)}")

    # ---- Train + hyperparam search (using validation set) ----
    best_models, best_params, best_val_score = train_and_eval(
        train_pairs, val_pairs, feature_columns,
        lr_list, emb_dim_list,
        device, args.epochs, args.batch_size
    )

    # ---- Test set attribution/evaluation ----
    print("[Evaluating attribution on test set: Precision@10 / NDCG@10 / Sparsity ...]")
    overall_prec, overall_ndcg, overall_sparsity, all_prec, all_ndcg, all_sparsity = evaluate_all_frames_graphsage_mean(
        test_nodes_dir, test_adj_dir, feature_columns, best_models, top_k=5, device=device
    )

    print("\n==== TestSet Summary ====")
    print(f"TestSet Precision@5: {overall_prec:.4f}")
    print(f"TestSet NDCG@5: {overall_ndcg:.4f}")
    print(f"TestSet Sparsity: {overall_sparsity:.4f}")

    # ==== Save results to results directory ====
    results_dir = "../../results"
    os.makedirs(results_dir, exist_ok=True)
    summary_path = os.path.join(results_dir, "graphsage_eval_summary.txt")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("==== GraphSAGE TestSet Evaluation Summary ====\n")
        f.write(f"TestSet Precision@5: {overall_prec:.4f}\n")
        f.write(f"TestSet NDCG@5: {overall_ndcg:.4f}\n")
        f.write(f"TestSet Sparsity: {overall_sparsity:.4f}\n")
    print(f"\nEvaluation results saved to: {summary_path}")

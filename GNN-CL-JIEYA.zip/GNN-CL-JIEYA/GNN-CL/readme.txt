This folder contains supplementary materials, data, and code for the paper:

Graph Neural Networks and Contrastive Learning Cooperative for Embedding Artificial Traffic Fluids with Multi-feature and Multi-scale Coupling (AAAI-26 Submission)

Project Overview
This work presents a unified framework for modeling artificial traffic fluids, using multi-layer risk-aware graphs, graph neural networks (GNNs), and contrastive learning. The approach captures both multi-feature risk and multi-scale vehicle interactions, and is benchmarked against classic baselines such as DeepWalk, Node2Vec, GraphSAGE, DGI, and MVGRL.
Due to file size limitations, only a subset of the highD and INTERACTION datasets is uploaded here. For the full datasets, please visit:https://www.highd-dataset.com/、https://interaction-dataset.com/



Folder Structure
GNN-CL/
│
├── code/                     
│   ├── Baseline/              
│   │   ├── Deepwalk.py
│   │   ├── DGI.py
│   │   ├── GraphSAGE.py
│   │   ├── MVGRL.py
│   │   └── Node2vec.py
│   │
│   ├── GNN-CL/                
│   │   ├── data_utils.py
│   │   ├── eval.py
│   │   ├── main.py
│   │   ├── model.py
│   │   └── train.py
│   │
│   └── preprocess/            
│       ├── highD_process.py
│       └── INTERACTION_process.py
│
├── data/
│   ├── raw/                   
│   │   ├── highD/
│   │   └── INTERACTION/
│   │
│   └── processed/             
│       ├── highD/
│       │   ├── adj/           
│       │   │   ├── train/
│       │   │   ├── val/
│       │   │   └── test/
│       │   └── nodes/      
│       │       ├── train/
│       │       ├── val/
│       │       └── test/
│       │
│       └── INTERACTION/
│           ├── adj/
│           │   ├── train/
│           │   ├── val/
│           │   └── test/
│           └── nodes/
│               ├── train/
│               ├── val/
│               └── test/
│
├── results/                  
├── README.md
└── requirements.txt




Workflow
1. Data Processing
Run highD_process.py and INTERACTION_process.py to convert raw highD and INTERACTION data into graph node and adjacency files. The processed data will be split into training, validation, and test sets under data/processed/highD/ and data/processed/INTERACTION/.

2. GNN-CL Model Training and Evaluation
Use train.py to train the proposed GNN-CL model. Model parameters will be saved to results/. After training, run eval.py to evaluate the GNN-CL model, and evaluation results will also be saved to results/.

3. Baseline Models Training and Evaluation
Run Deepwalk.py, DGI.py, GraphSAGE.py, MVGRL.py, and Node2vec.py under the Baseline/ folder to train and evaluate baseline models. Parameters and evaluation results will be saved to results/.



